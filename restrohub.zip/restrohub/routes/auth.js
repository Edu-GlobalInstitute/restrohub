const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { getDb } = require('../db/init');
const { authMiddleware } = require('../middleware/auth');

const router = express.Router();

function signToken(type, data) {
  return jwt.sign({ type, ...data }, process.env.JWT_SECRET, { expiresIn: '24h' });
}

// Super admin login
router.post('/super-login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ success: false, message: 'All fields required' });

  const db = getDb();
  const admin = db.prepare('SELECT * FROM super_admins WHERE username = ?').get(username);
  if (!admin || !bcrypt.compareSync(password, admin.password_hash)) {
    return res.status(401).json({ success: false, message: 'Invalid credentials' });
  }

  res.cookie('token', signToken('super', { id: admin.id, username: admin.username }), {
    httpOnly: true, sameSite: 'lax', maxAge: 86400000
  }).json({ success: true, message: 'Logged in', data: { type: 'super', username: admin.username } });
});

// Restaurant login
router.post('/restaurant-login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ success: false, message: 'All fields required' });

  const db = getDb();
  const rest = db.prepare('SELECT * FROM restaurants WHERE email = ?').get(email);
  if (!rest || !bcrypt.compareSync(password, rest.password_hash)) {
    return res.status(401).json({ success: false, message: 'Invalid credentials' });
  }

  res.cookie('token', signToken('restaurant', { id: rest.id, name: rest.name, email: rest.email }), {
    httpOnly: true, sameSite: 'lax', maxAge: 86400000
  }).json({ success: true, message: 'Logged in', data: { type: 'restaurant', id: rest.id, name: rest.name } });
});

// Verify token (used on page load)
router.get('/verify', authMiddleware, (req, res) => {
  res.json({ success: true, data: req.user });
});

// Impersonate restaurant (super admin viewing as restaurant)
router.post('/impersonate', authMiddleware, (req, res) => {
  if (req.user.type !== 'super') return res.status(403).json({ success: false, message: 'Forbidden' });
  const { restaurantId } = req.body;
  const db = getDb();
  const rest = db.prepare('SELECT id, name, email FROM restaurants WHERE id = ?').get(restaurantId);
  if (!rest) return res.status(404).json({ success: false, message: 'Restaurant not found' });

  res.cookie('token', signToken('restaurant', { id: rest.id, name: rest.name, email: rest.email }), {
    httpOnly: true, sameSite: 'lax', maxAge: 86400000
  }).json({ success: true, message: 'Switched', data: { type: 'restaurant', id: rest.id, name: rest.name } });
});

// Logout
router.post('/logout', (req, res) => {
  res.clearCookie('token').json({ success: true, message: 'Logged out' });
});

module.exports = router;