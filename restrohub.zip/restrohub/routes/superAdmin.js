const express = require('express');
const bcrypt = require('bcryptjs');
const { getDb } = require('../db/init');
const { authMiddleware, requireSuperAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(authMiddleware, requireSuperAdmin);

// List all restaurants
router.get('/restaurants', (req, res) => {
  const db = getDb();
  const restaurants = db.prepare('SELECT id, name, address, phone, email, categories, created_at FROM restaurants ORDER BY created_at DESC').all();
  const result = restaurants.map(r => {
    const menuCount = db.prepare('SELECT COUNT(*) as c FROM menu_items WHERE restaurant_id = ?').get(r.id).c;
    const orders = db.prepare('SELECT * FROM orders WHERE restaurant_id = ?').all(r.id);
    const revenue = orders.filter(o => o.status === 'billed').reduce((s, o) => s + o.total, 0);
    return { ...r, categories: JSON.parse(r.categories), menuCount, orderCount: orders.length, revenue };
  });
  res.json({ success: true, data: result });
});

// Create restaurant
router.post('/restaurants', (req, res) => {
  const { name, address, phone, email, password } = req.body;
  if (!name || !email || !password) return res.status(400).json({ success: false, message: 'Name, email and password required' });

  const db = getDb();
  if (db.prepare('SELECT id FROM restaurants WHERE email = ?').get(email)) {
    return res.status(409).json({ success: false, message: 'Email already registered' });
  }

  const id = Math.random().toString(36).slice(2) + Date.now().toString(36);
  const categories = JSON.stringify(['Starters','Main Course','Breads','Drinks','Desserts']);
  db.prepare('INSERT INTO restaurants (id, name, address, phone, email, password_hash, categories) VALUES (?,?,?,?,?,?,?)')
    .run(id, name, address || '', phone || '', email, bcrypt.hashSync(password, 10), categories);

  res.json({ success: true, message: 'Restaurant registered', data: { id, name } });
});

// Delete restaurant
router.delete('/restaurants/:id', (req, res) => {
  const db = getDb();
  const rest = db.prepare('SELECT id FROM restaurants WHERE id = ?').get(req.params.id);
  if (!rest) return res.status(404).json({ success: false, message: 'Not found' });

  // Delete photos from disk
  const photos = db.prepare(`SELECT mp.file_path FROM menu_photos mp
    JOIN menu_items mi ON mp.menu_item_id = mi.id WHERE mi.restaurant_id = ?`).all(req.params.id);
  const fs = require('fs');
  photos.forEach(p => { try { fs.unlinkSync(p.file_path); } catch {} });

  db.prepare('DELETE FROM restaurants WHERE id = ?').run(req.params.id);
  res.json({ success: true, message: 'Restaurant deleted' });
});

// Overview stats
router.get('/stats', (req, res) => {
  const db = getDb();
  const restCount = db.prepare('SELECT COUNT(*) as c FROM restaurants').get().c;
  const orderCount = db.prepare('SELECT COUNT(*) as c FROM orders').get().c;
  const revenue = db.prepare("SELECT COALESCE(SUM(total),0) as t FROM orders WHERE status = 'billed'").get().t;
  res.json({ success: true, data: { restCount, orderCount, revenue } });
});

module.exports = router;