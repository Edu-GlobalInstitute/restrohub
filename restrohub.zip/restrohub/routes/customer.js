const express = require('express');
const { getDb } = require('../db/init');

const router = express.Router();

// Get restaurant info for customer view
router.get('/:restaurantId/info', (req, res) => {
  const db = getDb();
  const rest = db.prepare('SELECT id, name, address, categories FROM restaurants WHERE id = ?').get(req.params.restaurantId);
  if (!rest) return res.status(404).json({ success: false, message: 'Restaurant not found' });

  const menu = db.prepare('SELECT * FROM menu_items WHERE restaurant_id = ? ORDER BY category, name').all(rest.id);
  const menuWithPhotos = menu.map(item => {
    const photos = db.prepare('SELECT id, file_path FROM menu_photos WHERE menu_item_id = ?').all(item.id);
    return { ...item, photos: photos.map(p => ({ id: p.id, url: '/' + p.file_path.replace(/\\/g, '/') })) };
  });

  res.json({ success: true, data: { ...rest, categories: JSON.parse(rest.categories), menu: menuWithPhotos } });
});

// Place order
router.post('/:restaurantId/order', (req, res) => {
  const { tableNo, customerName, items } = req.body;
  if (!tableNo || !customerName || !items || !items.length) {
    return res.status(400).json({ success: false, message: 'Table number, name and items required' });
  }

  const db = getDb();
  const rest = db.prepare('SELECT id FROM restaurants WHERE id = ?').get(req.params.restaurantId);
  if (!rest) return res.status(404).json({ success: false, message: 'Restaurant not found' });

  const orderId = Math.random().toString(36).slice(2) + Date.now().toString(36);
  let total = 0;

  db.transaction(() => {
    db.prepare('INSERT INTO orders (id, restaurant_id, table_no, customer_name, total, status) VALUES (?,?,?,?,?,?)')
      .run(orderId, req.params.restaurantId, parseInt(tableNo), customerName, 0, 'pending');

    const insertOI = db.prepare('INSERT INTO order_items (id, order_id, menu_item_id, item_name, price, qty) VALUES (?,?,?,?,?,?)');
    items.forEach(item => {
      total += item.price * item.qty;
      insertOI.run(Math.random().toString(36).slice(2) + Date.now().toString(36), orderId, item.itemId || null, item.name, item.price, item.qty);
    });

    db.prepare('UPDATE orders SET total = ? WHERE id = ?').run(total, orderId);
  })();

  res.json({ success: true, message: 'Order placed', data: { orderId, total } });
});

module.exports = router;