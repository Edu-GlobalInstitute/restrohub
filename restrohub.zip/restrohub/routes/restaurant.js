const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { getDb } = require('../db/init');
const { authMiddleware, requireRestaurant } = require('../middleware/auth');

const router = express.Router();
router.use(authMiddleware, requireRestaurant);

// Multer config for photo uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(__dirname, '..', 'uploads', 'menu-photos');
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, Date.now().toString(36) + Math.random().toString(36).slice(2, 6) + ext);
  }
});
const upload = multer({
  storage, limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (/^image\/(jpeg|png|webp)$/.test(file.mimetype)) cb(null, true);
    else cb(new Error('Only JPEG, PNG, WebP images allowed'));
  }
});

// Helper: get restaurant from token
function getRestId(req) { return req.user.id; }

// ===== OVERVIEW =====
router.get('/overview', (req, res) => {
  const db = getDb();
  const rid = getRestId(req);
  const now = Math.floor(Date.now() / 1000);
  const todayStart = now - (now % 86400);

  const todayOrders = db.prepare('SELECT * FROM orders WHERE restaurant_id = ? AND created_at >= ?').all(rid, todayStart);
  const todayRevenue = todayOrders.filter(o => o.status === 'billed').reduce((s, o) => s + o.total, 0);
  const pending = db.prepare("SELECT COUNT(*) as c FROM orders WHERE restaurant_id = ? AND status IN ('pending','preparing')").get(rid).c;
  const allOrders = db.prepare('SELECT * FROM orders WHERE restaurant_id = ?').all(rid);
  const avgOrder = allOrders.length > 0 ? Math.round(allOrders.reduce((s, o) => s + o.total, 0) / allOrders.length) : 0;
  const recent = db.prepare('SELECT * FROM orders WHERE restaurant_id = ? ORDER BY created_at DESC LIMIT 5').all(rid);

  res.json({ success: true, data: { todayOrders: todayOrders.length, todayRevenue, pending, avgOrder, recent } });
});

// ===== MENU =====
router.get('/menu', (req, res) => {
  const db = getDb();
  const items = db.prepare('SELECT * FROM menu_items WHERE restaurant_id = ? ORDER BY category, name').all(getRestId(req));
  const result = items.map(item => {
    const photos = db.prepare('SELECT id, file_path FROM menu_photos WHERE menu_item_id = ?').all(item.id);
    return { ...item, photos: photos.map(p => ({ id: p.id, url: '/' + p.file_path.replace(/\\/g, '/') })) };
  });
  res.json({ success: true, data: result });
});

router.post('/menu', (req, res) => {
  const { name, description, price, category } = req.body;
  if (!name || !price || !category) return res.status(400).json({ success: false, message: 'Name, price and category required' });

  const db = getDb();
  const id = Math.random().toString(36).slice(2) + Date.now().toString(36);
  db.prepare('INSERT INTO menu_items (id, restaurant_id, name, description, price, category) VALUES (?,?,?,?,?,?)')
    .run(id, getRestId(req), name, description || '', parseFloat(price), category);
  res.json({ success: true, message: 'Item added', data: { id } });
});

router.put('/menu/:id', (req, res) => {
  const { name, description, price, category } = req.body;
  if (!name || !price || !category) return res.status(400).json({ success: false, message: 'Name, price and category required' });

  const db = getDb();
  const item = db.prepare('SELECT * FROM menu_items WHERE id = ? AND restaurant_id = ?').get(req.params.id, getRestId(req));
  if (!item) return res.status(404).json({ success: false, message: 'Item not found' });

  db.prepare('UPDATE menu_items SET name=?, description=?, price=?, category=? WHERE id=?')
    .run(name, description || '', parseFloat(price), category, req.params.id);
  res.json({ success: true, message: 'Item updated' });
});

router.delete('/menu/:id', (req, res) => {
  const db = getDb();
  const item = db.prepare('SELECT * FROM menu_items WHERE id = ? AND restaurant_id = ?').get(req.params.id, getRestId(req));
  if (!item) return res.status(404).json({ success: false, message: 'Item not found' });

  // Delete photos from disk
  const photos = db.prepare('SELECT file_path FROM menu_photos WHERE menu_item_id = ?').all(req.params.id);
  photos.forEach(p => { try { fs.unlinkSync(p.file_path); } catch {} });

  db.prepare('DELETE FROM menu_items WHERE id = ?').run(req.params.id);
  res.json({ success: true, message: 'Item deleted' });
});

// Upload photos for a menu item
router.post('/menu/:id/photos', upload.array('photos', 5), (req, res) => {
  const db = getDb();
  const item = db.prepare('SELECT * FROM menu_items WHERE id = ? AND restaurant_id = ?').get(req.params.id, getRestId(req));
  if (!item) return res.status(404).json({ success: false, message: 'Item not found' });

  // Check current photo count
  const currentCount = db.prepare('SELECT COUNT(*) as c FROM menu_photos WHERE menu_item_id = ?').get(req.params.id).c;
  if (currentCount + req.files.length > 5) {
    // Remove uploaded files
    req.files.forEach(f => { try { fs.unlinkSync(f.path); } catch {} });
    return res.status(400).json({ success: false, message: 'Maximum 5 photos per item' });
  }

  const insert = db.prepare('INSERT INTO menu_photos (id, menu_item_id, file_path) VALUES (?,?,?)');
  const added = req.files.map(f => {
    const pid = Math.random().toString(36).slice(2) + Date.now().toString(36);
    insert.run(pid, req.params.id, f.path);
    return { id: pid, url: '/' + f.path.replace(/\\/g, '/') };
  });

  res.json({ success: true, message: 'Photos uploaded', data: added });
});

// Delete a single photo
router.delete('/menu/:id/photos/:photoId', (req, res) => {
  const db = getDb();
  const photo = db.prepare(`SELECT mp.* FROM menu_photos mp
    JOIN menu_items mi ON mp.menu_item_id = mi.id
    WHERE mp.id = ? AND mi.restaurant_id = ?`).get(req.params.photoId, getRestId(req));
  if (!photo) return res.status(404).json({ success: false, message: 'Photo not found' });

  try { fs.unlinkSync(photo.file_path); } catch {}
  db.prepare('DELETE FROM menu_photos WHERE id = ?').run(req.params.photoId);
  res.json({ success: true, message: 'Photo deleted' });
});

// Get restaurant info (for categories, name etc.)
router.get('/info', (req, res) => {
  const db = getDb();
  const rest = db.prepare('SELECT id, name, address, phone, email, categories FROM restaurants WHERE id = ?').get(getRestId(req));
  if (!rest) return res.status(404).json({ success: false, message: 'Not found' });
  res.json({ success: true, data: { ...rest, categories: JSON.parse(rest.categories) } });
});

// ===== ORDERS =====
router.get('/orders', (req, res) => {
  const db = getDb();
  const orders = db.prepare('SELECT * FROM orders WHERE restaurant_id = ? ORDER BY created_at DESC').all(getRestId(req));
  const result = orders.map(o => {
    const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(o.id);
    return { ...o, items };
  });
  res.json({ success: true, data: result });
});

router.put('/orders/:id/status', (req, res) => {
  const { status } = req.body;
  const valid = ['pending','preparing','ready','served','billed'];
  if (!valid.includes(status)) return res.status(400).json({ success: false, message: 'Invalid status' });

  const db = getDb();
  const order = db.prepare('SELECT * FROM orders WHERE id = ? AND restaurant_id = ?').get(req.params.id, getRestId(req));
  if (!order) return res.status(404).json({ success: false, message: 'Order not found' });

  db.prepare('UPDATE orders SET status = ? WHERE id = ?').run(status, req.params.id);
  res.json({ success: true, message: 'Status updated' });
});

router.get('/orders/:id', (req, res) => {
  const db = getDb();
  const order = db.prepare('SELECT o.*, r.name as rest_name, r.address, r.phone FROM orders o JOIN restaurants r ON o.restaurant_id = r.id WHERE o.id = ? AND o.restaurant_id = ?').get(req.params.id, getRestId(req));
  if (!order) return res.status(404).json({ success: false, message: 'Order not found' });
  const items = db.prepare('SELECT * FROM order_items WHERE order_id = ?').all(req.params.id);
  res.json({ success: true, data: { ...order, items } });
});

// ===== ANALYTICS =====
router.get('/analytics', (req, res) => {
  const db = getDb();
  const rid = getRestId(req);
  const now = Math.floor(Date.now() / 1000);

  // Revenue last 7 days
  const revenueByDay = [];
  for (let i = 6; i >= 0; i--) {
    const dayStart = now - (now % 86400) - (i * 86400);
    const dayEnd = dayStart + 86400;
    const rev = db.prepare("SELECT COALESCE(SUM(total),0) as t FROM orders WHERE restaurant_id = ? AND status = 'billed' AND created_at >= ? AND created_at < ?").get(rid, dayStart, dayEnd).t;
    const d = new Date(dayStart * 1000);
    revenueByDay.push({ label: d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric' }), value: rev });
  }

  // Popular items
  const popular = db.prepare(`SELECT oi.item_name as name, SUM(oi.qty) as qty
    FROM order_items oi JOIN orders o ON oi.order_id = o.id
    WHERE o.restaurant_id = ? GROUP BY oi.item_name ORDER BY qty DESC LIMIT 5`).all(rid);

  // Status distribution
  const statusDist = db.prepare(`SELECT status, COUNT(*) as count FROM orders WHERE restaurant_id = ? GROUP BY status`).all(rid);

  // Peak hours
  const hourCounts = db.prepare(`SELECT CAST(strftime('%H', datetime(created_at, 'unixepoch')) AS INTEGER) as hour, COUNT(*) as count
    FROM orders WHERE restaurant_id = ? GROUP BY hour`).all(rid);
  const peakHours = Array.from({ length: 24 }, (_, i) => ({
    label: i.toString().padStart(2, '0') + ':00',
    value: hourCounts.find(h => h.hour === i)?.count || 0
  }));

  res.json({ success: true, data: { revenueByDay, popular, statusDist, peakHours } });
});

// ===== QR =====
router.get('/qr-data', (req, res) => {
  const db = getDb();
  const rest = db.prepare('SELECT id, name FROM restaurants WHERE id = ?').get(getRestId(req));
  if (!rest) return res.status(404).json({ success: false, message: 'Not found' });

  const origin = process.env.PUBLIC_URL || `${req.protocol}://${req.get('host')}`;
  const url = `${origin}/customer?id=${rest.id}`;
  res.json({ success: true, data: { url, name: rest.name } });
});

module.exports = router;