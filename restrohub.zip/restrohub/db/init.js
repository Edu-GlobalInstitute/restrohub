const Database = require('better-sqlite3');
const path = require('path');
const bcrypt = require('bcryptjs');

const DB_PATH = path.join(__dirname, '..', 'restrohub.db');
let db;

function getDb() {
  if (!db) {
    db = new Database(DB_PATH);
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');
    createTables();
    seedIfEmpty();
  }
  return db;
}

function createTables() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS super_admins (
      id TEXT PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at INTEGER DEFAULT (unixepoch())
    );
    CREATE TABLE IF NOT EXISTS restaurants (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      address TEXT DEFAULT '',
      phone TEXT DEFAULT '',
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      categories TEXT DEFAULT '["Starters","Main Course","Breads","Drinks","Desserts"]',
      created_at INTEGER DEFAULT (unixepoch())
    );
    CREATE TABLE IF NOT EXISTS menu_items (
      id TEXT PRIMARY KEY,
      restaurant_id TEXT NOT NULL,
      name TEXT NOT NULL,
      description TEXT DEFAULT '',
      price REAL NOT NULL DEFAULT 0,
      category TEXT NOT NULL,
      created_at INTEGER DEFAULT (unixepoch()),
      FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS menu_photos (
      id TEXT PRIMARY KEY,
      menu_item_id TEXT NOT NULL,
      file_path TEXT NOT NULL,
      created_at INTEGER DEFAULT (unixepoch()),
      FOREIGN KEY (menu_item_id) REFERENCES menu_items(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      restaurant_id TEXT NOT NULL,
      table_no INTEGER NOT NULL DEFAULT 1,
      customer_name TEXT NOT NULL,
      total REAL NOT NULL DEFAULT 0,
      status TEXT DEFAULT 'pending',
      created_at INTEGER DEFAULT (unixepoch()),
      FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS order_items (
      id TEXT PRIMARY KEY,
      order_id TEXT NOT NULL,
      menu_item_id TEXT,
      item_name TEXT NOT NULL,
      price REAL NOT NULL DEFAULT 0,
      qty INTEGER NOT NULL DEFAULT 1,
      FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_menu_rest ON menu_items(restaurant_id);
    CREATE INDEX IF NOT EXISTS idx_photos_item ON menu_photos(menu_item_id);
    CREATE INDEX IF NOT EXISTS idx_orders_rest ON orders(restaurant_id);
    CREATE INDEX IF NOT EXISTS idx_oi_order ON order_items(order_id);
  `);
}

function uid() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function seedIfEmpty() {
  const count = db.prepare('SELECT COUNT(*) as c FROM super_admins').get().c;
  if (count > 0) return;

  // Super admin
  const saHash = bcrypt.hashSync('admin123', 10);
  db.prepare('INSERT INTO super_admins (id, username, password_hash) VALUES (?, ?, ?)').run(uid(), 'superadmin', saHash);

  // Restaurant 1: The Golden Spoon
  const r1Id = uid();
  db.prepare(`INSERT INTO restaurants (id, name, address, phone, email, password_hash, categories)
    VALUES (?, ?, ?, ?, ?, ?, ?)`).run(
    r1Id, 'The Golden Spoon', '42 MG Road, Connaught Place', '9876543210',
    'owner@goldenspoon.in', bcrypt.hashSync('pass123', 10),
    JSON.stringify(['Starters','Main Course','Breads','Drinks','Desserts'])
  );

  const r1Menu = [
    {n:'Paneer Tikka',d:'Marinated cottage cheese grilled in tandoor',p:280,c:'Starters'},
    {n:'Chicken Seekh Kebab',d:'Minced chicken skewers with aromatic spices',p:320,c:'Starters'},
    {n:'Butter Chicken',d:'Creamy tomato-based curry with tender chicken',p:380,c:'Main Course'},
    {n:'Dal Makhani',d:'Slow-cooked black lentils in rich gravy',p:260,c:'Main Course'},
    {n:'Biryani Hyderabadi',d:'Fragrant basmati rice layered with spiced meat',p:350,c:'Main Course'},
    {n:'Garlic Naan',d:'Soft bread baked with garlic and butter',p:60,c:'Breads'},
    {n:'Laccha Paratha',d:'Layered flaky whole wheat bread',p:50,c:'Breads'},
    {n:'Mango Lassi',d:'Chilled yogurt drink with fresh mango pulp',p:120,c:'Drinks'},
    {n:'Masala Chai',d:'Traditional spiced Indian tea',p:60,c:'Drinks'},
    {n:'Gulab Jamun',d:'Deep-fried milk dumplings in rose syrup',p:120,c:'Desserts'},
  ];

  const insertItem = db.prepare('INSERT INTO menu_items (id, restaurant_id, name, description, price, category) VALUES (?,?,?,?,?,?)');
  r1Menu.forEach(m => insertItem.run(uid(), r1Id, m.n, m.d, m.p, m.c));

  // Restaurant 2: Urban Bites
  const r2Id = uid();
  db.prepare(`INSERT INTO restaurants (id, name, address, phone, email, password_hash, categories)
    VALUES (?, ?, ?, ?, ?, ?, ?)`).run(
    r2Id, 'Urban Bites', '15 Brigade Road, Koramangala', '9876543211',
    'hello@urbanbites.in', bcrypt.hashSync('pass123', 10),
    JSON.stringify(['Starters','Main Course','Drinks','Desserts'])
  );

  const r2Menu = [
    {n:'Truffle Fries',d:'Crispy fries with truffle oil and parmesan',p:220,c:'Starters'},
    {n:'Loaded Nachos',d:'Tortilla chips with cheese, salsa and sour cream',p:250,c:'Starters'},
    {n:'Classic Burger',d:'Juicy beef patty with lettuce, tomato and sauce',p:320,c:'Main Course'},
    {n:'Margherita Pizza',d:'Wood-fired pizza with fresh mozzarella and basil',p:350,c:'Main Course'},
    {n:'Pasta Alfredo',d:'Creamy white sauce pasta with grilled chicken',p:300,c:'Main Course'},
    {n:'Mojito',d:'Fresh mint and lime mocktail',p:150,c:'Drinks'},
    {n:'Cold Coffee',d:'Blended iced coffee with cream',p:140,c:'Drinks'},
    {n:'Brownie Sundae',d:'Warm chocolate brownie with vanilla ice cream',p:200,c:'Desserts'},
  ];

  r2Menu.forEach(m => insertItem.run(uid(), r2Id, m.n, m.d, m.p, m.c));

  // Sample orders
  const insertOrder = db.prepare('INSERT INTO orders (id, restaurant_id, table_no, customer_name, total, status, created_at) VALUES (?,?,?,?,?,?,?)');
  const insertOI = db.prepare('INSERT INTO order_items (id, order_id, menu_item_id, item_name, price, qty) VALUES (?,?,?,?,?,?)');
  const names = ['Rahul','Priya','Amit','Sneha','Vikram','Ananya','Rohan','Meera'];
  const statuses = ['pending','preparing','ready','served','billed'];
  const now = Math.floor(Date.now()/1000);

  [r1Id, r2Id].forEach(restId => {
    const items = db.prepare('SELECT id, name, price FROM menu_items WHERE restaurant_id = ?').all(restId);
    for (let i = 0; i < 8; i++) {
      const oId = uid();
      const table = Math.floor(Math.random()*10)+1;
      const numItems = Math.floor(Math.random()*3)+1;
      let total = 0;
      for (let j = 0; j < numItems; j++) {
        const item = items[Math.floor(Math.random()*items.length)];
        const qty = Math.floor(Math.random()*2)+1;
        total += item.price * qty;
        insertOI.run(uid(), oId, item.id, item.name, item.price, qty);
      }
      const status = statuses[i<2?0:i<4?1:i<5?2:i<7?3:4];
      insertOrder.run(oId, restId, table, names[i], total, status, now - (i*3600 + Math.floor(Math.random()*3600)));
    }
  });
}

module.exports = { getDb, uid };