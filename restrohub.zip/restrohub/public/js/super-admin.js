(async function () {
  const user = await requireAuth('super');
  if (!user) return;
  await loadDashboard();
})();

async function loadDashboard() {
  const [statsRes, restsRes] = await Promise.all([
    api('/admin/stats'),
    api('/admin/restaurants')
  ]);
  if (!statsRes.success || !restsRes.success) return toast('Failed to load data', 'error');

  const { restCount, orderCount, revenue } = statsRes.data;
  const restaurants = restsRes.data;

  document.getElementById('content').innerHTML = `
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 animate-slide-up">
      <div><h2 class="font-display text-2xl font-bold">All Restaurants</h2><p class="text-muted text-sm mt-1">Manage your restaurant network</p></div>
      <button onclick="openRegisterModal()" class="btn-primary text-sm"><i class="fas fa-plus"></i>Add Restaurant</button>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
      <div class="glass-card p-5 animate-slide-up" style="animation-delay:.1s">
        <div class="flex items-center justify-between"><span class="text-muted text-sm">Total Restaurants</span><div class="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center"><i class="fas fa-store text-accent"></i></div></div>
        <p class="text-3xl font-bold mt-3">${restCount}</p>
      </div>
      <div class="glass-card p-5 animate-slide-up" style="animation-delay:.2s">
        <div class="flex items-center justify-between"><span class="text-muted text-sm">Total Orders</span><div class="w-10 h-10 rounded-xl bg-warm/10 flex items-center justify-center"><i class="fas fa-receipt text-warm"></i></div></div>
        <p class="text-3xl font-bold mt-3">${orderCount}</p>
      </div>
      <div class="glass-card p-5 animate-slide-up" style="animation-delay:.3s">
        <div class="flex items-center justify-between"><span class="text-muted text-sm">Total Revenue</span><div class="w-10 h-10 rounded-xl bg-green-900/30 flex items-center justify-center"><i class="fas fa-indian-rupee-sign text-green-400"></i></div></div>
        <p class="text-3xl font-bold mt-3">${formatCurrency(revenue)}</p>
      </div>
    </div>

    <div class="glass-card overflow-hidden animate-slide-up" style="animation-delay:.4s">
      <div class="p-5 border-b border-border"><h3 class="font-semibold">Registered Restaurants</h3></div>
      ${restaurants.length === 0 ? '<div class="p-10 text-center text-muted">No restaurants yet</div>' : `
      <div class="overflow-x-auto"><table class="w-full text-sm">
        <thead><tr class="text-left text-muted border-b border-border">
          <th class="p-4 font-medium">Restaurant</th><th class="p-4 font-medium hidden sm:table-cell">Location</th>
          <th class="p-4 font-medium">Menu</th><th class="p-4 font-medium">Orders</th><th class="p-4 font-medium">Revenue</th><th class="p-4 font-medium">Actions</th>
        </tr></thead>
        <tbody>${restaurants.map(r => `<tr class="border-b border-border/50 hover:bg-card/50 transition-colors">
          <td class="p-4"><div class="font-medium">${r.name}</div><div class="text-xs text-muted mt-0.5">${r.email}</div></td>
          <td class="p-4 text-muted hidden sm:table-cell">${r.address || '-'}</td>
          <td class="p-4">${r.menuCount}</td><td class="p-4">${r.orderCount}</td>
          <td class="p-4 font-medium">${formatCurrency(r.revenue)}</td>
          <td class="p-4"><div class="flex gap-2">
            <button onclick="viewAs('${r.id}')" class="text-xs text-accent hover:text-accent-hover" title="View Dashboard"><i class="fas fa-external-link-alt"></i></button>
            <button onclick="deleteRest('${r.id}','${r.name}')" class="text-xs text-red-400 hover:text-red-300" title="Delete"><i class="fas fa-trash"></i></button>
          </div></td>
        </tr>`).join('')}</tbody>
      </table></div>`}
    </div>`;
}

function openRegisterModal() {
  showModal(`
    <h3 class="font-display text-xl font-bold mb-6">Register New Restaurant</h3>
    <div class="space-y-4">
      <div><label class="text-sm text-muted mb-1.5 block">Restaurant Name</label><input id="reg-name" class="input-field" placeholder="e.g. The Golden Spoon"></div>
      <div><label class="text-sm text-muted mb-1.5 block">Address</label><input id="reg-addr" class="input-field" placeholder="Full address"></div>
      <div class="grid grid-cols-2 gap-4">
        <div><label class="text-sm text-muted mb-1.5 block">Phone</label><input id="reg-phone" class="input-field" placeholder="9876543210"></div>
        <div><label class="text-sm text-muted mb-1.5 block">Email</label><input id="reg-email" class="input-field" placeholder="owner@restaurant.com"></div>
      </div>
      <div><label class="text-sm text-muted mb-1.5 block">Admin Password</label><input id="reg-pass" type="password" class="input-field" placeholder="Set a password"></div>
      <div class="flex gap-3 pt-2">
        <button onclick="closeModal()" class="btn-secondary flex-1">Cancel</button>
        <button onclick="registerRest()" class="btn-primary flex-1">Register</button>
      </div>
    </div>`);
}

async function registerRest() {
  const name = document.getElementById('reg-name').value.trim();
  const address = document.getElementById('reg-addr').value.trim();
  const phone = document.getElementById('reg-phone').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const password = document.getElementById('reg-pass').value;
  if (!name || !email || !password) return toast('Name, email and password required', 'error');

  const res = await api('/admin/restaurants', { method: 'POST', body: { name, address, phone, email, password } });
  if (res.success) { closeModal(); toast('Restaurant registered!', 'success'); loadDashboard(); }
  else toast(res.message, 'error');
}

async function viewAs(id) {
  const res = await api('/auth/impersonate', { method: 'POST', body: { restaurantId: id } });
  if (res.success) { toast('Switched to restaurant view', 'success'); window.location.href = '/dashboard'; }
  else toast(res.message, 'error');
}

function deleteRest(id, name) {
  showModal(`<div class="text-center p-4">
    <div class="w-14 h-14 rounded-full bg-red-900/30 flex items-center justify-center mx-auto mb-4"><i class="fas fa-exclamation-triangle text-red-400 text-xl"></i></div>
    <h3 class="font-display text-xl font-bold mb-2">Delete ${name}?</h3>
    <p class="text-muted text-sm mb-6">This will permanently remove the restaurant and all its data.</p>
    <div class="flex gap-3 justify-center">
      <button onclick="closeModal()" class="btn-secondary text-sm">Cancel</button>
      <button onclick="confirmDelete('${id}')" class="text-sm font-semibold px-6 py-2.5 rounded-xl bg-red-600 text-white hover:bg-red-500 transition-colors">Delete</button>
    </div>
  </div>`);
}

async function confirmDelete(id) {
  const res = await api('/admin/restaurants/' + id, { method: 'DELETE' });
  if (res.success) { closeModal(); toast('Restaurant deleted', 'success'); loadDashboard(); }
  else toast(res.message, 'error');
}