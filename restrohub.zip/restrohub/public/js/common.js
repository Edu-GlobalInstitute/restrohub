// Shared utilities for all pages
const API = window.location.origin + '/api';

async function api(url, options = {}) {
  const opts = {
    headers: { 'Content-Type': 'application/json' },
    ...options
  };
  if (opts.body && typeof opts.body === 'object') opts.body = JSON.stringify(opts.body);
  const res = await fetch(API + url, opts);
  const data = await res.json();
  if (!data.success && res.status === 401) {
    window.location.href = '/login';
    return data;
  }
  return data;
}

function formatCurrency(n) {
  return '₹' + Number(n).toLocaleString('en-IN', { minimumFractionDigits: 0 });
}

function formatDate(ts) {
  return new Date(ts * 1000).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

function formatTime(ts) {
  return new Date(ts * 1000).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
}

function formatDateTime(ts) {
  return formatDate(ts) + ' ' + formatTime(ts);
}

function statusBadge(s) {
  const map = {
    pending: ['badge-pending', 'Pending'],
    preparing: ['badge-preparing', 'Preparing'],
    ready: ['badge-ready', 'Ready'],
    served: ['badge-served', 'Served'],
    billed: ['badge-billed', 'Billed']
  };
  const [cls, label] = map[s] || ['badge-served', s];
  return `<span class="badge ${cls}">${label}</span>`;
}

// Toast notification system
function toast(msg, type = 'info') {
  const c = document.getElementById('toast-container');
  if (!c) return;
  const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', info: 'fa-info-circle' };
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.innerHTML = `<i class="fas ${icons[type]}"></i><span>${msg}</span>`;
  c.appendChild(t);
  setTimeout(() => {
    t.style.opacity = '0';
    t.style.transform = 'translateX(100px)';
    t.style.transition = 'all .3s';
    setTimeout(() => t.remove(), 300);
  }, 3000);
}

// Modal system
function showModal(html, onClose) {
  const c = document.getElementById('modal-container');
  if (!c) return;
  c.innerHTML = `<div class="modal-overlay" id="modal-overlay"><div class="modal-content p-6">${html}</div></div>`;
  document.getElementById('modal-overlay').addEventListener('click', e => {
    if (e.target.id === 'modal-overlay') { closeModal(); if (onClose) onClose(); }
  });
}
function closeModal() {
  const c = document.getElementById('modal-container');
  if (c) c.innerHTML = '';
}

// Auth check — redirect if not logged in or wrong type
async function requireAuth(expectedType) {
  try {
    const res = await api('/auth/verify');
    if (!res.success || res.data.type !== expectedType) {
      window.location.href = '/login';
      return null;
    }
    return res.data;
  } catch {
    window.location.href = '/login';
    return null;
  }
}

async function logout() {
  await api('/auth/logout', { method: 'POST' });
  window.location.href = '/login';
}

// Loading state
function showLoading(container) {
  if (container) container.innerHTML = '<div class="flex justify-center py-20"><div class="spinner"></div></div>';
}

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeModal();
});