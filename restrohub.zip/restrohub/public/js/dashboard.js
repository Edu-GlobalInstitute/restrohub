let currentUser = null;
let restaurantInfo = null;
let currentTab = 'overview';
let menuData = [];
let orderData = [];
let chartInstances = [];

(async function () {
  currentUser = await requireAuth('restaurant');
  if (!currentUser) return;
  const infoRes = await api('/restaurant/info');
  if (!infoRes.success) return toast('Failed to load', 'error');
  restaurantInfo = infoRes.data;
  renderNav();
  switchTab('overview');
})();

function renderNav() {
  const tabs = [
    { id: 'overview', icon: 'fa-chart-pie', label: 'Overview' },
    { id: 'menu', icon: 'fa-book-open', label: 'Menu' },
    { id: 'orders', icon: 'fa-receipt', label: 'Orders' },
    { id: 'analytics', icon: 'fa-chart-bar', label: 'Analytics' },
    { id: 'qr', icon: 'fa-qrcode', label: 'QR Code' }
  ];
  document.getElementById('main-nav').innerHTML = `
    <div class="sticky top-0 z-50 bg-surface/90 backdrop-blur-md border-b border-border">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        <div class="flex items-center gap-3">
          <div class="w-9 h-9 rounded-lg bg-gradient-to-br from-accent to-warm flex items-center justify-center">
            <i class="fas fa-utensils text-bg text-sm"></i>
          </div>
          <span class="font-display font-bold text-lg text-light">${restaurantInfo.name}</span>
        </div>
        <div class="hidden md:flex items-center gap-1">
          ${tabs.map(t => `<button onclick="switchTab('${t.id}')" class="tab-btn ${currentTab === t.id ? 'active' : ''} text-sm"><i class="fas ${t.icon} mr-1.5"></i>${t.label}</button>`).join('')}
        </div>
        <button onclick="logout()" class="btn-secondary text-sm py-2 px-4"><i class="fas fa-sign-out-alt mr-1"></i>Logout</button>
      </div>
      <div class="md:hidden flex gap-1 px-4 pb-2 overflow-x-auto">
        ${tabs.map(t => `<button onclick="switchTab('${t.id}')" class="tab-btn ${currentTab === t.id ? 'active' : ''} text-xs whitespace-nowrap"><i class="fas ${t.icon} mr-1"></i>${t.label}</button>`).join('')}
      </div>
    </div>`;
}

function destroyCharts() { chartInstances.forEach(c => c.destroy()); chartInstances = []; }

function switchTab(tab) {
  destroyCharts();
  currentTab = tab;
  renderNav();
  const el = document.getElementById('dash-content');
  showLoading(el);

  switch (tab) {
    case 'overview': loadOverview(el); break;
    case 'menu': loadMenu(el); break;
    case 'orders': loadOrders(el); break;
    case 'analytics': loadAnalytics(el); break;
    case 'qr': loadQR(el); break;
  }
}

// ===== OVERVIEW =====
async function loadOverview(el) {
  const res = await api('/restaurant/overview');
  if (!res.success) return el.innerHTML = '<p class="text-muted py-20 text-center">Failed to load</p>';
  const d = res.data;

  el.innerHTML = `
    <div class="mb-8 animate-slide-up"><h2 class="font-display text-2xl font-bold">Dashboard</h2><p class="text-muted text-sm mt-1">Here's what's happening today.</p></div>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      ${statCard("Today's Revenue", formatCurrency(d.todayRevenue), 'fa-indian-rupee-sign', 'text-green-400', 'bg-green-900/20', '.1s')}
      ${statCard("Today's Orders", d.todayOrders, 'fa-receipt', 'text-accent', 'bg-accent/10', '.2s')}
      ${statCard('Pending Orders', d.pending, 'fa-clock', 'text-orange-400', 'bg-orange-900/20', '.3s')}
      ${statCard('Avg Order Value', formatCurrency(d.avgOrder), 'fa-chart-line', 'text-blue-400', 'bg-blue-900/20', '.4s')}
    </div>
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div class="glass-card p-5 animate-slide-up" style="animation-delay:.5s">
        <h3 class="font-semibold mb-4">Recent Orders</h3>
        ${d.recent.length === 0 ? '<p class="text-muted text-sm py-4">No orders yet</p>' : `
        <div class="space-y-3">${d.recent.map(o => `
          <div class="flex items-center justify-between p-3 rounded-xl bg-bg/50">
            <div><span class="font-medium text-sm">Table ${o.table_no}</span><span class="text-muted text-xs ml-2">${o.customer_name}</span></div>
            <div class="flex items-center gap-3"><span class="text-sm font-medium">${formatCurrency(o.total)}</span>${statusBadge(o.status)}</div>
          </div>`).join('')}</div>`}
      </div>
      <div class="glass-card p-5 animate-slide-up" style="animation-delay:.6s">
        <h3 class="font-semibold mb-4">Quick Actions</h3>
        <div class="grid grid-cols-2 gap-3">
          <button onclick="switchTab('menu')" class="p-4 rounded-xl bg-bg/50 hover:bg-card border border-border hover:border-accent/30 transition-all text-left"><i class="fas fa-plus-circle text-accent mb-2"></i><p class="text-sm font-medium">Add Menu Item</p></button>
          <button onclick="switchTab('orders')" class="p-4 rounded-xl bg-bg/50 hover:bg-card border border-border hover:border-accent/30 transition-all text-left"><i class="fas fa-list-check text-warm mb-2"></i><p class="text-sm font-medium">Manage Orders</p></button>
          <button onclick="switchTab('qr')" class="p-4 rounded-xl bg-bg/50 hover:bg-card border border-border hover:border-accent/30 transition-all text-left"><i class="fas fa-qrcode text-green-400 mb-2"></i><p class="text-sm font-medium">View QR Code</p></button>
          <button onclick="switchTab('analytics')" class="p-4 rounded-xl bg-bg/50 hover:bg-card border border-border hover:border-accent/30 transition-all text-left"><i class="fas fa-chart-bar text-blue-400 mb-2"></i><p class="text-sm font-medium">Analytics</p></button>
        </div>
      </div>
    </div>`;
}

function statCard(label, value, icon, iconColor, iconBg, delay) {
  return `<div class="glass-card p-5 animate-slide-up" style="animation-delay:${delay}">
    <div class="flex items-center justify-between"><span class="text-muted text-sm">${label}</span><div class="w-10 h-10 rounded-xl ${iconBg} flex items-center justify-center"><i class="fas ${icon} ${iconColor}"></i></div></div>
    <p class="text-2xl font-bold mt-3">${value}</p>
  </div>`;
}

// ===== MENU =====
let menuCatFilter = 'All';

async function loadMenu(el) {
  menuCatFilter = 'All';
  const res = await api('/restaurant/menu');
  if (!res.success) return el.innerHTML = '<p class="text-muted py-20 text-center">Failed to load</p>';
  menuData = res.data;
  renderMenu(el);
}

function renderMenu(el) {
  const cats = restaurantInfo.categories;
  const filtered = menuCatFilter === 'All' ? menuData : menuData.filter(i => i.category === menuCatFilter);

  el.innerHTML = `
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 animate-slide-up">
      <div><h2 class="font-display text-2xl font-bold">Menu Management</h2><p class="text-muted text-sm mt-1">${menuData.length} items across ${cats.length} categories</p></div>
      <button onclick="openItemModal()" class="btn-primary text-sm"><i class="fas fa-plus"></i>Add Item</button>
    </div>
    <div class="flex gap-2 mb-6 overflow-x-auto pb-2 animate-slide-up" style="animation-delay:.1s">
      ${['All', ...cats].map(c => `<button onclick="menuCatFilter='${c}';renderMenu(document.getElementById('dash-content'))" class="tab-btn ${menuCatFilter === c ? 'active' : ''} text-sm whitespace-nowrap">${c}</button>`).join('')}
    </div>
    ${filtered.length === 0 ? '<div class="glass-card p-12 text-center animate-slide-up"><i class="fas fa-utensils text-4xl text-muted/30 mb-3"></i><p class="text-muted">No items in this category</p></div>' : `
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      ${filtered.map((item, idx) => `
      <div class="glass-card overflow-hidden animate-slide-up" style="animation-delay:${.1 + idx * .05}s">
        <div class="relative">
          ${item.photos && item.photos[0] ? `<img src="${item.photos[0].url}" class="w-full h-40 object-cover">` : '<div class="w-full h-40 bg-bg flex items-center justify-center"><i class="fas fa-image text-3xl text-muted/20"></i></div>'}
          <span class="absolute top-3 left-3 badge badge-pending text-xs">${item.category}</span>
          ${item.photos && item.photos.length > 1 ? `<span class="absolute top-3 right-3 badge bg-black/50 text-xs"><i class="fas fa-images mr-1"></i>${item.photos.length}</span>` : ''}
        </div>
        <div class="p-4">
          <div class="flex justify-between items-start mb-1"><h4 class="font-semibold">${item.name}</h4><span class="text-accent font-bold whitespace-nowrap ml-2">${formatCurrency(item.price)}</span></div>
          <p class="text-muted text-xs line-clamp-2 mb-3">${item.description}</p>
          <div class="flex gap-2">
            <button onclick="openItemModal('${item.id}')" class="flex-1 text-xs py-2 rounded-lg bg-accent/10 text-accent hover:bg-accent/20 transition-colors"><i class="fas fa-edit mr-1"></i>Edit</button>
            <button onclick="deleteMenuItem('${item.id}','${item.name}')" class="px-3 py-2 rounded-lg bg-red-900/20 text-red-400 hover:bg-red-900/30 transition-colors text-xs"><i class="fas fa-trash"></i></button>
          </div>
        </div>
      </div>`).join('')}
    </div>`}`;
}

let editItemPhotos = [];

function openItemModal(itemId) {
  const item = itemId ? menuData.find(i => i.id === itemId) : null;
  editItemPhotos = item ? item.photos.map(p => ({ id: p.id, url: p.url })) : [];

  showModal(`
    <h3 class="font-display text-xl font-bold mb-6">${item ? 'Edit' : 'Add New'} Menu Item</h3>
    <div class="space-y-4">
      <div><label class="text-sm text-muted mb-1.5 block">Item Name</label><input id="mi-name" class="input-field" value="${item ? item.name : ''}" placeholder="e.g. Butter Chicken"></div>
      <div><label class="text-sm text-muted mb-1.5 block">Description</label><textarea id="mi-desc" class="input-field" rows="2" placeholder="Brief description">${item ? item.description : ''}</textarea></div>
      <div class="grid grid-cols-2 gap-4">
        <div><label class="text-sm text-muted mb-1.5 block">Price (₹)</label><input id="mi-price" type="number" class="input-field" value="${item ? item.price : ''}" placeholder="0"></div>
        <div><label class="text-sm text-muted mb-1.5 block">Category</label><select id="mi-cat" class="input-field">${restaurantInfo.categories.map(c => `<option ${item && item.category === c ? 'selected' : ''}>${c}</option>`).join('')}</select></div>
      </div>
      <div>
        <label class="text-sm text-muted mb-1.5 block">Photos (up to 5)</label>
        <div id="mi-photos" class="flex gap-3 flex-wrap">
          ${editItemPhotos.map((p, i) => `<div class="relative group"><img src="${p.url}" class="w-20 h-20 rounded-lg object-cover"><button type="button" onclick="removeEditPhoto('${p.id}',${i})" class="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-red-600 text-white text-xs flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"><i class="fas fa-times"></i></button></div>`).join('')}
          ${editItemPhotos.length < 5 ? `<label class="w-20 h-20 rounded-lg border-2 border-dashed border-border flex flex-col items-center justify-center cursor-pointer hover:border-accent/50 transition-colors"><i class="fas fa-camera text-muted text-sm"></i><span class="text-xs text-muted mt-1">Add</span><input type="file" accept="image/jpeg,image/png,image/webp" class="hidden" onchange="uploadPhoto(this,'${itemId || ''}')"></label>` : ''}
        </div>
      </div>
      <div class="flex gap-3 pt-2">
        <button onclick="closeModal()" class="btn-secondary flex-1">Cancel</button>
        <button onclick="saveItem('${itemId || ''}')" class="btn-primary flex-1">${item ? 'Update' : 'Add'} Item</button>
      </div>
    </div>`);
}

async function uploadPhoto(input, itemId) {
  if (!input.files[0]) return;
  const file = input.files[0];
  const fd = new FormData();
  fd.append('photos', file);

  const res = await fetch(API + `/restaurant/menu/${itemId}/photos`, { method: 'POST', body: fd });
  const data = await res.json();
  if (!data.success) return toast(data.message || 'Upload failed', 'error');

  editItemPhotos.push(...data.data);
  refreshEditPhotos(itemId);
  toast('Photo uploaded', 'success');
}

async function removeEditPhoto(photoId, idx) {
  if (!photoId) { editItemPhotos.splice(idx, 1); refreshEditPhotos(''); return; }
  const itemId = document.getElementById('mi-name')?.closest('.space-y-4')?.querySelector('[onclick*="saveItem"]')?.getAttribute('onclick')?.match(/saveItem\('?(.*?)'?\)/)?.[1] || '';
  const res = await api(`/restaurant/menu/${itemId}/photos/${photoId}`, { method: 'DELETE' });
  if (res.success) { editItemPhotos.splice(idx, 1); refreshEditPhotos(itemId); toast('Photo removed', 'success'); }
  else toast(res.message, 'error');
}

function refreshEditPhotos(itemId) {
  const c = document.getElementById('mi-photos');
  if (!c) return;
  c.innerHTML = editItemPhotos.map((p, i) => `<div class="relative group"><img src="${p.url}" class="w-20 h-20 rounded-lg object-cover"><button type="button" onclick="removeEditPhoto('${p.id}',${i})" class="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-red-600 text-white text-xs flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"><i class="fas fa-times"></i></button></div>`).join('') +
    (editItemPhotos.length < 5 ? `<label class="w-20 h-20 rounded-lg border-2 border-dashed border-border flex flex-col items-center justify-center cursor-pointer hover:border-accent/50 transition-colors"><i class="fas fa-camera text-muted text-sm"></i><span class="text-xs text-muted mt-1">Add</span><input type="file" accept="image/jpeg,image/png,image/webp" class="hidden" onchange="uploadPhoto(this,'${itemId}')"></label>` : '');
}

async function saveItem(itemId) {
  const name = document.getElementById('mi-name').value.trim();
  const description = document.getElementById('mi-desc').value.trim();
  const price = parseFloat(document.getElementById('mi-price').value);
  const category = document.getElementById('mi-cat').value;
  if (!name || !price) return toast('Name and price required', 'error');

  const url = itemId ? `/restaurant/menu/${itemId}` : '/restaurant/menu';
  const method = itemId ? 'PUT' : 'POST';
  const res = await api(url, { method, body: { name, description, price, category } });

  if (res.success) {
    // If new item and we have pending photos, upload them now
    if (!itemId && editItemPhotos.length === 0) {
      // No photos to upload
    } else if (!itemId) {
      // Photos were already uploaded (they need itemId), so re-open to add photos
    }
    closeModal(); toast(itemId ? 'Item updated' : 'Item added', 'success');
    loadMenu(document.getElementById('dash-content'));
  } else toast(res.message, 'error');
}

function deleteMenuItem(id, name) {
  showModal(`<div class="text-center p-4">
    <div class="w-14 h-14 rounded-full bg-red-900/30 flex items-center justify-center mx-auto mb-4"><i class="fas fa-trash text-red-400 text-xl"></i></div>
    <h3 class="font-display text-xl font-bold mb-2">Delete "${name}"?</h3>
    <p class="text-muted text-sm mb-6">This cannot be undone.</p>
    <div class="flex gap-3 justify-center">
      <button onclick="closeModal()" class="btn-secondary text-sm">Cancel</button>
      <button onclick="confirmDeleteItem('${id}')" class="text-sm font-semibold px-6 py-2.5 rounded-xl bg-red-600 text-white hover:bg-red-500">Delete</button>
    </div>
  </div>`);
}

async function confirmDeleteItem(id) {
  const res = await api(`/restaurant/menu/${id}`, { method: 'DELETE' });
  if (res.success) { closeModal(); toast('Item deleted', 'success'); loadMenu(document.getElementById('dash-content')); }
  else toast(res.message, 'error');
}

// ===== ORDERS =====
let orderFilter = 'all';

async function loadOrders(el) {
  orderFilter = 'all';
  const res = await api('/restaurant/orders');
  if (!res.success) return el.innerHTML = '<p class="text-muted py-20 text-center">Failed</p>';
  orderData = res.data;
  renderOrders(el);
}

function renderOrders(el) {
  const filtered = orderFilter === 'all' ? orderData : orderData.filter(o => o.status === orderFilter);
  const statusOpts = ['all', 'pending', 'preparing', 'ready', 'served', 'billed'];

  el.innerHTML = `
    <div class="mb-6 animate-slide-up"><h2 class="font-display text-2xl font-bold">Orders</h2><p class="text-muted text-sm mt-1">${orderData.length} total</p></div>
    <div class="flex gap-2 mb-6 overflow-x-auto pb-2 animate-slide-up" style="animation-delay:.1s">
      ${statusOpts.map(f => `<button onclick="orderFilter='${f}';renderOrders(document.getElementById('dash-content'))" class="tab-btn ${orderFilter === f ? 'active' : ''} text-sm whitespace-nowrap capitalize">${f}</button>`).join('')}
    </div>
    ${filtered.length === 0 ? '<div class="glass-card p-12 text-center animate-slide-up"><i class="fas fa-receipt text-4xl text-muted/30 mb-3"></i><p class="text-muted">No orders found</p></div>' : `
    <div class="space-y-3">${filtered.map((o, idx) => `
      <div class="glass-card p-5 animate-slide-up" style="animation-delay:${.1 + idx * .05}s">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center"><span class="text-accent font-bold text-sm">T${o.table_no}</span></div>
            <div><p class="font-medium">${o.customer_name}</p><p class="text-xs text-muted">${formatDateTime(o.created_at)}</p></div>
          </div>
          <div class="flex items-center gap-3"><span class="text-lg font-bold">${formatCurrency(o.total)}</span>${statusBadge(o.status)}</div>
        </div>
        <div class="bg-bg/50 rounded-xl p-3 mb-3">${o.items.map(it => `<div class="flex justify-between text-sm"><span>${it.item_name} x${it.qty}</span><span class="text-muted">${formatCurrency(it.price * it.qty)}</span></div>`).join('')}</div>
        <div class="flex flex-wrap gap-2">
          <select onchange="updateStatus('${o.id}',this.value)" class="input-field text-sm py-1.5 px-3 w-auto">
            ${['pending','preparing','ready','served','billed'].map(s => `<option value="${s}" ${o.status === s ? 'selected' : ''}>${s.charAt(0).toUpperCase() + s.slice(1)}</option>`).join('')}
          </select>
          ${o.status === 'billed' ? `<button onclick="viewBill('${o.id}')" class="btn-primary text-xs py-2 px-4"><i class="fas fa-file-invoice mr-1"></i>Bill</button>` : ''}
        </div>
      </div>`).join('')}</div>`}`;
}

async function updateStatus(orderId, status) {
  const res = await api(`/restaurant/orders/${orderId}/status`, { method: 'PUT', body: { status } });
  if (res.success) { toast('Status updated', 'success'); loadOrders(document.getElementById('dash-content')); }
  else toast(res.message, 'error');
}

async function viewBill(orderId) {
  const res = await api(`/restaurant/orders/${orderId}`);
  if (!res.success) return toast('Failed to load bill', 'error');
  const o = res.data;
  const tax = Math.round(o.total * 0.05);
  const grand = o.total + tax;

  showModal(`<div class="print-area p-6">
    <div class="text-center mb-6 pb-4 border-b-2 border-dashed border-border">
      <h2 class="font-display text-2xl font-bold">${o.rest_name}</h2>
      <p class="text-muted text-sm mt-1">${o.address}</p><p class="text-muted text-sm">Phone: ${o.phone}</p>
    </div>
    <div class="grid grid-cols-2 gap-4 mb-4 text-sm">
      <div><span class="text-muted">Table:</span><span class="font-medium ml-2">${o.table_no}</span></div>
      <div class="text-right"><span class="text-muted">Date:</span><span class="font-medium ml-2">${formatDateTime(o.created_at)}</span></div>
      <div><span class="text-muted">Customer:</span><span class="font-medium ml-2">${o.customer_name}</span></div>
      <div class="text-right"><span class="text-muted">Order:</span><span class="font-medium ml-2">${o.id.slice(-8).toUpperCase()}</span></div>
    </div>
    <table class="w-full text-sm mb-4">
      <thead><tr class="border-b border-border"><th class="text-left py-2 font-medium text-muted">Item</th><th class="text-center py-2 font-medium text-muted">Qty</th><th class="text-right py-2 font-medium text-muted">Amount</th></tr></thead>
      <tbody>${o.items.map(it => `<tr class="border-b border-border/50"><td class="py-2">${it.item_name}</td><td class="text-center py-2">${it.qty}</td><td class="text-right py-2">${formatCurrency(it.price * it.qty)}</td></tr>`).join('')}</tbody>
    </table>
    <div class="border-t-2 border-dashed border-border pt-3 space-y-1.5 text-sm">
      <div class="flex justify-between"><span class="text-muted">Subtotal</span><span>${formatCurrency(o.total)}</span></div>
      <div class="flex justify-between"><span class="text-muted">Tax (5%)</span><span>${formatCurrency(tax)}</span></div>
      <div class="flex justify-between text-lg font-bold pt-2 border-t border-border"><span>Total</span><span class="text-accent">${formatCurrency(grand)}</span></div>
    </div>
    <div class="text-center mt-6 pt-4 border-t-2 border-dashed border-border"><p class="text-sm text-muted">Thank you for dining with us!</p></div>
    <div class="flex gap-3 mt-6 no-print">
      <button onclick="closeModal()" class="btn-secondary flex-1 text-sm">Close</button>
      <button onclick="window.print()" class="btn-primary flex-1 text-sm"><i class="fas fa-print mr-2"></i>Print</button>
    </div>
  </div>`);
}

// ===== ANALYTICS =====
async function loadAnalytics(el) {
  const res = await api('/restaurant/analytics');
  if (!res.success) return el.innerHTML = '<p class="text-muted py-20 text-center">Failed</p>';
  const d = res.data;

  el.innerHTML = `
    <div class="mb-8 animate-slide-up"><h2 class="font-display text-2xl font-bold">Analytics</h2><p class="text-muted text-sm mt-1">Growth insights</p></div>
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div class="glass-card p-5 animate-slide-up" style="animation-delay:.1s"><h3 class="font-semibold mb-4">Revenue (Last 7 Days)</h3><canvas id="chart-rev" height="200"></canvas></div>
      <div class="glass-card p-5 animate-slide-up" style="animation-delay:.2s"><h3 class="font-semibold mb-4">Popular Items</h3><canvas id="chart-pop" height="200"></canvas></div>
      <div class="glass-card p-5 animate-slide-up" style="animation-delay:.3s"><h3 class="font-semibold mb-4">Order Status</h3><canvas id="chart-status" height="200"></canvas></div>
      <div class="glass-card p-5 animate-slide-up" style="animation-delay:.4s"><h3 class="font-semibold mb-4">Peak Hours</h3><canvas id="chart-hours" height="200"></canvas></div>
    </div>`;

  setTimeout(() => {
    const opts = { responsive: true, maintainAspectRatio: false, plugins: { legend: { labels: { color: '#8A8279', font: { family: 'DM Sans' } } } } };
    const scale = { scales: { x: { ticks: { color: '#8A8279' }, grid: { color: '#2A2A2A' } }, y: { ticks: { color: '#8A8279' }, grid: { color: '#2A2A2A' } } } };

    chartInstances.push(new Chart(document.getElementById('chart-rev'), {
      type: 'line', data: { labels: d.revenueByDay.map(r => r.label), datasets: [{ label: 'Revenue', data: d.revenueByDay.map(r => r.value), borderColor: '#D4A039', backgroundColor: 'rgba(212,160,57,0.1)', fill: true, tension: .4, pointBackgroundColor: '#D4A039' }] }, options: { ...opts, ...scale }
    }));

    chartInstances.push(new Chart(document.getElementById('chart-pop'), {
      type: 'bar', data: { labels: d.popular.map(p => p.name), datasets: [{ label: 'Qty Sold', data: d.popular.map(p => p.qty), backgroundColor: ['#D4A039','#C75B2A','#5b8def','#7ddf7d','#c77ddf'], borderRadius: 8, barThickness: 24 }] },
      options: { ...opts, indexAxis: 'y', scales: { x: { ticks: { color: '#8A8279' }, grid: { color: '#2A2A2A' } }, y: { ticks: { color: '#F0EBE3', font: { size: 12 } }, grid: { display: false } } } }
    }));

    const statusColors = { pending: '#D4A039', preparing: '#5b8def', ready: '#7ddf7d', served: '#888', billed: '#c77ddf' };
    chartInstances.push(new Chart(document.getElementById('chart-status'), {
      type: 'doughnut', data: { labels: d.statusDist.map(s => s.status.charAt(0).toUpperCase() + s.status.slice(1)), datasets: [{ data: d.statusDist.map(s => s.count), backgroundColor: d.statusDist.map(s => statusColors[s.status] || '#888'), borderWidth: 0 }] }, options: { ...opts, cutout: '65%' }
    }));

    chartInstances.push(new Chart(document.getElementById('chart-hours'), {
      type: 'bar', data: { labels: d.peakHours.map(h => h.label), datasets: [{ label: 'Orders', data: d.peakHours.map(h => h.value), backgroundColor: d.peakHours.map(h => h.value > 0 ? 'rgba(212,160,57,0.7)' : 'rgba(42,42,42,0.5)'), borderRadius: 4, barThickness: 12 }] }, options: { ...opts, ...scale }
    }));
  }, 100);
}

// ===== QR CODE =====
async function loadQR(el) {
  const res = await api('/restaurant/qr-data');
  if (!res.success) return el.innerHTML = '<p class="text-muted py-20 text-center">Failed</p>';
  const { url, name } = res.data;

  el.innerHTML = `
    <div class="mb-8 animate-slide-up"><h2 class="font-display text-2xl font-bold">QR Code</h2><p class="text-muted text-sm mt-1">Customers scan to order</p></div>
    <div class="max-w-lg mx-auto">
      <div class="glass-card p-8 text-center animate-scale-in">
        <div class="inline-block p-6 bg-white rounded-2xl mb-6"><div id="qr-box"></div></div>
        <h3 class="font-display text-xl font-bold mb-2">${name}</h3>
        <p class="text-muted text-sm mb-6">Scan to order</p>
        <div class="bg-bg/50 rounded-xl p-3 mb-6 break-all text-xs text-muted">${url}</div>
        <div class="flex gap-3 justify-center">
          <button onclick="downloadQR()" class="btn-primary text-sm"><i class="fas fa-download mr-2"></i>Download QR</button>
          <button onclick="navigator.clipboard.writeText('${url}').then(()=>toast('Copied','success'))" class="btn-secondary text-sm"><i class="fas fa-copy mr-2"></i>Copy Link</button>
        </div>
      </div>
      <div class="glass-card p-5 mt-6 animate-slide-up" style="animation-delay:.2s">
        <h4 class="font-semibold mb-3"><i class="fas fa-info-circle text-accent mr-2"></i>How to Use</h4>
        <ol class="text-sm text-muted space-y-2 list-decimal list-inside">
          <li>Download and print the QR code</li>
          <li>Place it on each table</li>
          <li>Customers scan with their phone camera</li>
          <li>They select table, browse menu, and order</li>
          <li>Orders appear in your Orders tab</li>
        </ol>
      </div>
    </div>`;

  setTimeout(() => {
    const box = document.getElementById('qr-box');
    if (box && box.childElementCount === 0) {
      new QRCode(box, { text: url, width: 200, height: 200, colorDark: '#0C0C0C', colorLight: '#FFFFFF', correctLevel: QRCode.CorrectLevel.H });
    }
  }, 100);
}

function downloadQR() {
  const canvas = document.querySelector('#qr-box canvas');
  if (!canvas) return toast('QR not ready', 'error');
  const a = document.createElement('a');
  a.download = 'restrohub-qr.png';
  a.href = canvas.toDataURL('image/png');
  a.click();
  toast('QR downloaded', 'success');
}