const CA = window.location.origin + '/api/customer';
let cState = { phase: 'loading', restId: null, rest: null, tableNo: null, cart: [], customerName: '', catFilter: 'All', suggestions: [] };

(async function () {
  const params = new URLSearchParams(window.location.search);
  const restId = params.get('id');
  if (!restId) return showError('Invalid link — no restaurant ID provided');

  cState.restId = restId;
  try {
    const res = await fetch(CA + '/' + restId + '/info');
    const data = await res.json();
    if (!data.success) return showError('Restaurant not found. This QR link may be invalid.');
    cState.rest = data.data;
    cState.phase = 'greeting';
    renderGreeting();
  } catch (e) {
    showError('Could not connect to server. Check your internet connection.');
  }
})();

function showError(msg) {
  document.getElementById('app').innerHTML = `
    <div class="min-h-screen flex items-center justify-center">
      <div class="text-center">
        <div class="w-16 h-16 rounded-full bg-red-900/30 flex items-center justify-center mx-auto mb-4">
          <i class="fas fa-exclamation-triangle text-red-400 text-2xl"></i>
        </div>
        <p class="text-xl font-medium mb-2">Something went wrong</p>
        <p class="text-muted text-sm">${msg}</p>
      </div>
    </div>`;
}

function renderGreeting() {
  document.getElementById('app').innerHTML = `
    <div class="min-h-screen flex items-center justify-center relative overflow-hidden">
      <div class="orb orb-1" style="top:5%;left:5%"></div>
      <div class="orb orb-2" style="bottom:10%;right:5%"></div>
      <div class="orb orb-3" style="top:40%;right:30%"></div>
      <div class="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-bg"></div>
      <div class="text-center relative z-10 px-4">
        <p class="text-muted text-sm tracking-[0.3em] uppercase mb-4" style="animation:fadeIn .8s ease .2s both">Welcome to</p>
        <h1 class="font-display text-5xl sm:text-7xl font-black shimmer-text mb-6" style="animation:fadeIn 1s ease .5s both">${cState.rest.name}</h1>
        <div class="greeting-line mx-auto mb-6"></div>
        <p class="text-light-dim text-lg" style="animation:fadeIn .8s ease 1.2s both">Scan complete. Please take your seat.</p>
        <div class="mt-10" style="animation:fadeIn .8s ease 1.8s both">
          <button onclick="renderTableInput()" class="btn-primary text-lg px-10 py-4 rounded-2xl" style="animation:pulse-glow 2s infinite">Begin Ordering</button>
        </div>
      </div>
    </div>`;
}

function renderTableInput() {
  cState.phase = 'table';
  document.getElementById('app').innerHTML = `
    <div class="min-h-screen flex items-center justify-center relative overflow-hidden">
      <div class="orb orb-1" style="top:20%;right:10%"></div>
      <div class="glass-card p-8 w-full max-w-sm mx-4 animate-scale-in text-center relative z-10">
        <div class="w-16 h-16 rounded-2xl bg-accent/10 flex items-center justify-center mx-auto mb-5">
          <i class="fas fa-chair text-accent text-2xl"></i>
        </div>
        <h2 class="font-display text-2xl font-bold mb-2">Table Number</h2>
        <p class="text-muted text-sm mb-6">Enter the number shown on your table</p>
        <input id="table-input" type="number" class="input-field text-center text-3xl font-bold tracking-widest mb-6" placeholder="—" min="1" max="100">
        <button onclick="submitTable()" class="btn-primary w-full text-lg py-4">Confirm</button>
      </div>
    </div>`;
  setTimeout(() => {
    const inp = document.getElementById('table-input');
    if (inp) inp.focus();
  }, 200);
  document.getElementById('table-input')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') submitTable();
  });
}

function submitTable() {
  const val = parseInt(document.getElementById('table-input').value);
  if (!val || val < 1) return toast('Enter a valid table number', 'error');
  cState.tableNo = val;
  cState.phase = 'menu';
  renderMenu();
}

function renderMenu() {
  const menu = cState.rest.menu;
  const cats = cState.rest.categories;
  const filtered = cState.catFilter === 'All' ? menu : menu.filter(i => i.category === cState.catFilter);
  const cartCount = cState.cart.reduce((s, c) => s + c.qty, 0);
  const cartTotal = cState.cart.reduce((s, c) => s + c.price * c.qty, 0);

  document.getElementById('app').innerHTML = `
    <div class="min-h-screen bg-bg">
      <header class="sticky top-0 z-50 bg-surface/95 backdrop-blur-md border-b border-border">
        <div class="max-w-3xl mx-auto px-4 h-14 flex items-center justify-between">
          <div class="flex items-center gap-3">
            <span class="font-display font-bold">${cState.rest.name}</span>
            <span class="badge badge-pending">Table ${cState.tableNo}</span>
          </div>
          <button onclick="openCart()" class="relative p-2 rounded-xl hover:bg-card transition-colors">
            <i class="fas fa-shopping-bag text-lg"></i>
            ${cartCount > 0 ? `<span class="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-accent text-bg text-xs font-bold flex items-center justify-center">${cartCount}</span>` : ''}
          </button>
        </div>
        <div class="max-w-3xl mx-auto px-4 pb-3 flex gap-2 overflow-x-auto">
          ${['All', ...cats].map(c => `<button onclick="cState.catFilter='${c}';renderMenu()" class="tab-btn ${cState.catFilter === c ? 'active' : ''} text-xs whitespace-nowrap py-1.5 px-3">${c}</button>`).join('')}
        </div>
      </header>

      <main class="max-w-3xl mx-auto px-4 py-6 pb-32">
        ${filtered.length === 0 ? '<div class="text-center py-16 text-muted"><i class="fas fa-utensils text-3xl mb-3 opacity-30"></i><p>No items in this category</p></div>' : `
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          ${filtered.map((item, idx) => {
            const inCart = cState.cart.find(c => c.itemId === item.id);
            return `
            <div class="menu-card animate-slide-up" style="animation-delay:${idx * .05}s">
              ${item.photos && item.photos[0] ? `<img src="${item.photos[0].url}" class="w-full h-44 object-cover" loading="lazy">` : '<div class="w-full h-44 bg-card flex items-center justify-center"><i class="fas fa-image text-3xl text-muted/20"></i></div>'}
              <div class="p-4">
                <div class="flex justify-between items-start mb-1">
                  <h4 class="font-semibold text-sm leading-tight">${item.name}</h4>
                  <span class="text-accent font-bold text-sm whitespace-nowrap ml-2">${formatCurrency(item.price)}</span>
                </div>
                <p class="text-muted text-xs mb-3 line-clamp-2">${item.description}</p>
                ${inCart ? `
                  <div class="flex items-center justify-between">
                    <button onclick="updateCart('${item.id}',-1)" class="w-9 h-9 rounded-lg bg-bg border border-border flex items-center justify-center hover:border-accent transition-colors"><i class="fas fa-minus text-xs"></i></button>
                    <span class="font-bold">${inCart.qty}</span>
                    <button onclick="updateCart('${item.id}',1)" class="w-9 h-9 rounded-lg bg-accent text-bg flex items-center justify-center hover:bg-accent-hover transition-colors"><i class="fas fa-plus text-xs"></i></button>
                  </div>` : `
                  <button onclick="addToCart('${item.id}')" class="w-full py-2.5 rounded-xl bg-accent/10 text-accent text-sm font-medium hover:bg-accent/20 transition-colors"><i class="fas fa-plus mr-1.5"></i>Add to Order</button>`}
              </div>
            </div>`;
          }).join('')}
        </div>`}
      </main>

      ${cartCount > 0 ? `
      <div class="fixed bottom-0 left-0 right-0 z-40 p-4 bg-gradient-to-t from-bg via-bg to-transparent pointer-events-none">
        <button onclick="openCart()" class="pointer-events-auto btn-primary w-full max-w-3xl mx-auto flex items-center justify-between text-base py-4 rounded-2xl">
          <span><i class="fas fa-shopping-bag mr-2"></i>${cartCount} item${cartCount > 1 ? 's' : ''}</span>
          <span class="font-bold">${formatCurrency(cartTotal)}</span>
        </button>
      </div>` : ''}
    </div>`;

  closeCart();
}

function addToCart(itemId) {
  const item = cState.rest.menu.find(i => i.id === itemId);
  if (!item) return;

  const existing = cState.cart.find(c => c.itemId === itemId);
  if (existing) {
    existing.qty++;
  } else {
    cState.cart.push({ itemId: item.id, name: item.name, price: item.price, qty: 1, category: item.category });
  }

  generateSuggestions(item);
  renderMenu();
  // Small delay then auto-open cart to show suggestion
  setTimeout(() => openCart(), 200);
}

function updateCart(itemId, delta) {
  const item = cState.cart.find(c => c.itemId === itemId);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) cState.cart = cState.cart.filter(c => c.itemId !== itemId);
  renderMenu();
}

function generateSuggestions(addedItem) {
  cState.suggestions = [];
  const inCartIds = new Set(cState.cart.map(c => c.itemId));
  const isDrink = addedItem.category === 'Drinks';
  const isDessert = addedItem.category === 'Desserts';

  if (!isDrink && !isDessert) {
    const drinks = cState.rest.menu.filter(i => i.category === 'Drinks' && !inCartIds.has(i.id));
    cState.suggestions = drinks.sort(() => Math.random() - .5).slice(0, 2);
  } else if (isDrink) {
    const starters = cState.rest.menu.filter(i => i.category === 'Starters' && !inCartIds.has(i.id));
    cState.suggestions = starters.sort(() => Math.random() - .5).slice(0, 2);
  }
}

function openCart() {
  const panel = document.getElementById('cart-panel');
  const overlay = document.getElementById('cart-overlay');
  if (!panel || !overlay) return;

  const cartTotal = cState.cart.reduce((s, c) => s + c.price * c.qty, 0);
  const tax = Math.round(cartTotal * 0.05);
  const grand = cartTotal + tax;

  let suggestionsHtml = '';
  if (cState.suggestions.length > 0) {
    suggestionsHtml = `
      <div class="px-5 pt-4">
        <div class="bg-accent/5 border border-accent/20 rounded-xl p-3 mb-2" style="animation:slideUp .4s ease">
          <p class="text-xs text-accent font-medium mb-2"><i class="fas fa-lightbulb mr-1"></i>Frequently ordered together</p>
          <div class="space-y-2">
            ${cState.suggestions.map(s => `
              <div class="flex items-center justify-between bg-bg/50 rounded-lg p-2">
                <span class="text-sm">${s.name}</span>
                <div class="flex items-center gap-2">
                  <span class="text-xs text-muted">${formatCurrency(s.price)}</span>
                  <button onclick="addToCart('${s.id}')" class="w-7 h-7 rounded-lg bg-accent text-bg flex items-center justify-center text-xs hover:bg-accent-hover transition-colors"><i class="fas fa-plus"></i></button>
                </div>
              </div>`).join('')}
          </div>
        </div>
      </div>`;
    // Clear suggestions after showing
    setTimeout(() => { cState.suggestions = []; }, 15000);
  }

  panel.innerHTML = `
    <div class="p-5 border-b border-border flex items-center justify-between">
      <h3 class="font-display text-lg font-bold">Your Order</h3>
      <button onclick="closeCart()" class="w-9 h-9 rounded-lg hover:bg-card flex items-center justify-center transition-colors"><i class="fas fa-times"></i></button>
    </div>
    ${suggestionsHtml}
    <div class="px-5 py-4 flex-1 overflow-y-auto">
      ${cState.cart.length === 0 ? '<div class="text-center py-10 text-muted"><i class="fas fa-shopping-bag text-3xl mb-3 opacity-30"></i><p>Your order is empty</p></div>' : `
      <div class="space-y-3">
        ${cState.cart.map(c => `
          <div class="flex items-center justify-between">
            <div class="flex-1 mr-3">
              <p class="text-sm font-medium">${c.name}</p>
              <p class="text-xs text-muted">${formatCurrency(c.price)} each</p>
            </div>
            <div class="flex items-center gap-2">
              <button onclick="updateCart('${c.itemId}',-1);openCart()" class="w-8 h-8 rounded-lg bg-bg border border-border flex items-center justify-center text-xs hover:border-accent transition-colors"><i class="fas fa-minus"></i></button>
              <span class="text-sm font-bold w-5 text-center">${c.qty}</span>
              <button onclick="updateCart('${c.itemId}',1);openCart()" class="w-8 h-8 rounded-lg bg-accent text-bg flex items-center justify-center text-xs"><i class="fas fa-plus"></i></button>
            </div>
          </div>`).join('')}
      </div>`}
    </div>
    ${cState.cart.length > 0 ? `
    <div class="p-5 border-t border-border">
      <div class="space-y-2 mb-4 text-sm">
        <div class="flex justify-between text-muted"><span>Subtotal</span><span>${formatCurrency(cartTotal)}</span></div>
        <div class="flex justify-between text-muted"><span>Tax (5%)</span><span>${formatCurrency(tax)}</span></div>
        <div class="flex justify-between text-lg font-bold pt-2 border-t border-border"><span>Total</span><span class="text-accent">${formatCurrency(grand)}</span></div>
      </div>
      <div class="mb-3">
        <label class="text-sm text-muted mb-1.5 block">Your Name</label>
        <input id="cust-name" class="input-field" placeholder="Enter your name" value="${cState.customerName}">
      </div>
      <button onclick="placeOrder()" class="btn-primary w-full text-base py-3.5" id="place-order-btn">
        <i class="fas fa-check mr-2"></i>Place Order
      </button>
    </div>` : ''}`;

  panel.classList.add('open');
  overlay.classList.add('open');
}

function closeCart() {
  document.getElementById('cart-panel')?.classList.remove('open');
  document.getElementById('cart-overlay')?.classList.remove('open');
}

async function placeOrder() {
  if (cState.cart.length === 0) return toast('Your cart is empty', 'error');
  const nameInput = document.getElementById('cust-name');
  const name = nameInput ? nameInput.value.trim() : '';
  if (!name) return toast('Please enter your name', 'error');

  cState.customerName = name;

  const btn = document.getElementById('place-order-btn');
  if (btn) { btn.disabled = true; btn.innerHTML = '<div class="spinner" style="width:20px;height:20px;border-width:2px;"></div> Placing...'; }

  try {
    const res = await fetch(CA + '/' + cState.restId + '/order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        tableNo: cState.tableNo,
        customerName: name,
        items: cState.cart.map(c => ({ itemId: c.itemId, name: c.name, price: c.price, qty: c.qty }))
      })
    });
    const data = await res.json();

    if (data.success) {
      closeCart();
      renderConfirmation(data.data);
    } else {
      toast(data.message || 'Failed to place order', 'error');
      if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-check mr-2"></i>Place Order'; }
    }
  } catch (e) {
    toast('Network error. Please try again.', 'error');
    if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-check mr-2"></i>Place Order'; }
  }
}

function renderConfirmation(orderData) {
  const cartTotal = cState.cart.reduce((s, c) => s + c.price * c.qty, 0);
  document.getElementById('app').innerHTML = `
    <div class="min-h-screen flex items-center justify-center relative overflow-hidden">
      <div class="orb orb-1" style="top:30%;left:20%"></div>
      <div class="orb orb-2" style="bottom:20%;right:15%"></div>
      <div class="glass-card p-8 w-full max-w-md mx-4 text-center animate-scale-in relative z-10">
        <div class="w-20 h-20 rounded-full bg-green-900/30 flex items-center justify-center mx-auto mb-6" style="animation:pulse-glow 2s infinite">
          <i class="fas fa-check-circle text-green-400 text-4xl"></i>
        </div>
        <h2 class="font-display text-2xl font-bold mb-2">Order Placed!</h2>
        <p class="text-muted text-sm mb-6">Your order has been sent to the kitchen. Sit back and relax!</p>
        <div class="bg-bg/50 rounded-xl p-4 mb-6 text-left space-y-2">
          <div class="flex justify-between text-sm"><span class="text-muted">Table</span><span class="font-medium">${cState.tableNo}</span></div>
          <div class="flex justify-between text-sm"><span class="text-muted">Name</span><span class="font-medium">${cState.customerName}</span></div>
          <div class="flex justify-between text-sm"><span class="text-muted">Items</span><span class="font-medium">${cState.cart.length}</span></div>
          <div class="flex justify-between text-sm border-t border-border pt-2">
            <span class="text-muted">Total</span>
            <span class="font-bold text-accent">${formatCurrency(cartTotal)}</span>
          </div>
        </div>
        <button onclick="cState.cart=[];cState.suggestions=[];renderMenu()" class="btn-primary w-full">Order More</button>
      </div>
    </div>`;
}