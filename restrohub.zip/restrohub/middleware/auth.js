const jwt = require('jsonwebtoken');

function authMiddleware(req, res, next) {
  const token = req.cookies?.token;
  if (!token) return res.status(401).json({ success: false, message: 'Not authenticated' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch {
    res.status(401).json({ success: false, message: 'Invalid or expired token' });
  }
}

function requireSuperAdmin(req, res, next) {
  if (req.user?.type !== 'super') return res.status(403).json({ success: false, message: 'Super admin only' });
  next();
}

function requireRestaurant(req, res, next) {
  if (req.user?.type !== 'restaurant') return res.status(403).json({ success: false, message: 'Restaurant only' });
  next();
}

module.exports = { authMiddleware, requireSuperAdmin, requireRestaurant };